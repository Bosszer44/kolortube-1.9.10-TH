<?php
/** Silence is golden. */
